EOA: Incidence Matrices for 32 Alphabets and Scripts
Author: Bahaa BuDargham
ORCID: 0009-0005-2955-3703

CONTENTS:
- 36 CSV files (one for each alphabet). 
- verify.py (a short script to compute the Perron eigenvalues).

DESCRIPTION:
These matrices represent the structural naming networks of letters. A value at row i, column j indicates how many times symbol j appears in the name of symbol i. 

IMPORTANT: The specific internal operator used to map the letter names to these matrices is withheld under a staged disclosure agreement. However, the mathematical findings in the paper rely ONLY on these resulting matrices, which are fully provided here.

HOW TO VERIFY:
Run verify.py in Python (requires numpy and sympy). It will load the matrices and output the Perron eigenvalue for each, demonstrating the exact algebraic constants (e.g., 1+sqrt(2), phi^2) reported in the paper.