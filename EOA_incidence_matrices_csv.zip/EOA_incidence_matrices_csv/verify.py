import numpy as np
import sympy as sp
import glob
import os

def perron_from_csv(filename):
    # Load matrix
    M_np = np.loadtxt(filename, delimiter=',')
    
    # Perron eigenvalue: largest modulus eigenvalue from numpy (fast, stable)
    eigenvalues = np.linalg.eigvals(M_np)
    perron = float(np.max(np.abs(eigenvalues)))
    
    # Factored charpoly: exact integer arithmetic via sympy (this is the proof)
    M = sp.Matrix(M_np.astype(int).tolist())
    x = sp.symbols('x')
    cp = M.charpoly(x)
    factored = sp.factor(cp.as_expr())
    
    return factored, perron

files = sorted(glob.glob("*.csv"))
print(f"Found {len(files)} CSV files\n")

for file in files:
    name = os.path.splitext(file)[0]
    try:
        factored, perron = perron_from_csv(file)
        print(f"=== {name} ===")
        print(f"Factored charpoly: {factored}")
        print(f"Perron eigenvalue: {perron:.10f}")
        print()
    except Exception as e:
        print(f"=== {name} === FAILED: {e}\n")